USERS.txt - Names + ID's of our team
requirements.txt - The External libraries we downloaded
main_subtask1.py - Main python file for the first challenge of the Hackathon
main_subtask2.py - Main python file for the second challenge of the Hackathon
Project.pdf - explanations about our thinking process, Plots we created to understand the Data better, insights we
gained from the data, and some suggestion in order to improve the transportation system in Israel.
predictions - CSV of predictions of the two subtask we got.
1- The number of the task we choose in the Hackathon.

